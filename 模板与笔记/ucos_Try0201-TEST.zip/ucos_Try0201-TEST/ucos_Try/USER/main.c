#include "led.h"
#include "beep.h"
#include "delay.h"
#include "key.h"
#include "pwm.h"
#include "sys.h"
#include "usart.h"	 
#include "timer.h" 
#include "includes.h" 	 

 

/************************************************
 ALIENTEKս��STM32������ʵ��51
 UCOSIIʵ��2-2-���񴴽���ɾ�������𣬻ָ�
 ����֧�֣�www.openedv.com
 �Ա����̣� http://eboard.taobao.com 
 ��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡSTM32���ϡ�
 �������������ӿƼ����޹�˾  
 ���ߣ�����ԭ�� @ALIENTEK
************************************************/


 
/////////////////////////UCOSII�����ջ����///////////////////////////////////
//START ����
//�����������ȼ�
#define START_TASK_PRIO      			10 //��ʼ��������ȼ�����Ϊ���
//���������ջ��С
#define START_STK_SIZE  				64
//���������ջ�ռ�	
OS_STK START_TASK_STK[START_STK_SIZE];
//�������ӿ�
void start_task(void *pdata);	
 			   
//LED����
//�����������ȼ�
#define LED_TASK_PRIO       			6 
//���������ջ��С
#define LED_STK_SIZE  		    		64
//���������ջ�ռ�	
OS_STK LED_TASK_STK[LED_STK_SIZE];
//�������ӿ�
void led_task(void *pdata);


//13����
//�����������ȼ�
#define LEG13_TASK_PRIO       			5 
//���������ջ��С
#define LEG13_STK_SIZE  					64
//���������ջ�ռ�	
OS_STK LEG13_TASK_STK[LEG13_STK_SIZE];
//�������ӿ�
void LEG13_task(void *pdata);

//24����
//�����������ȼ�
#define LEG24_TASK_PRIO       			4 
//���������ջ��С
#define LEG24_STK_SIZE  					64
//���������ջ�ռ�	
OS_STK LEG24_TASK_STK[LEG24_STK_SIZE];
//�������ӿ�
void LEG24_task(void *pdata);


//����ɨ������
//�����������ȼ�
#define KEY_TASK_PRIO       			3 
//���������ջ��С
#define KEY_STK_SIZE  					64
//���������ջ�ռ�	
OS_STK KEY_TASK_STK[KEY_STK_SIZE];
//�������ӿ�
void key_task(void *pdata);
			
			
OS_EVENT *sem_1ms,*sem_leg13,*sem_leg24;
			
OS_TMR   * tmr1;			//������ʱ��1			
void tmr1_callback(OS_TMR *ptmr,void *p_arg) ;		

extern u16 leg_val[9];
u16 leg_ori_val[9],leg_val_real[9];
uint16_t Bleg_val[5],Sleg_val[5],m_nPWMTimer,m_nPWMTimer_2;
u8 m_cPeriodNum,state_13,m_cPeriodNum_2,state_24;
///////////////////////////
struct st_mortor_param
{ 
	//
	unsigned int p1_time;					//pace period1 length of time
	 int p1_bleg_init;		//pace period1 big leg initial value
	unsigned char p1_bleg_add;		//pace period1 big leg add value
	unsigned char p1_bleg_sub;		//pace period1 big leg subtract value
	 int p1_sleg_init;		//pace period1 small leg initial value
	unsigned char p1_sleg_add;		//pace period1 small leg add value
	unsigned char p1_sleg_sub;		//pace period1 small leg subtract value
	//
	unsigned int p2_time;					//pace period2 length of time
	 int p2_bleg_init;		//pace period2 big leg initial value
	unsigned char p2_bleg_add;		//pace period2 big leg add value
	unsigned char p2_bleg_sub;		//pace period2 big leg subtract value
	 int p2_sleg_init;		//pace period2 small leg initial value
	unsigned char p2_sleg_add;		//pace period2 small leg add value
	unsigned char p2_sleg_sub;		//pace period2 small leg subtract value
	//  
	unsigned int p3_time;					//pace period3 length of time
	 int p3_bleg_init;		//pace period3 big leg initial value
	unsigned char p3_bleg_add;		//pace period3 big leg add value
	unsigned char p3_bleg_sub;		//pace period3 big leg subtract value
	 int p3_sleg_init;		//pace period3 small leg initial value
	unsigned char p3_sleg_add;		//pace period3 small leg add value
	unsigned char p3_sleg_sub;		//pace period3 small leg subtract value
	//
	unsigned int p4_time;					//pace period4 length of time
	 int p4_bleg_init;		//pace period4 big leg initial value
	unsigned char p4_bleg_add;		//pace period4 big leg add value
	unsigned char p4_bleg_sub;		//pace period4 big leg subtract value
	 int p4_sleg_init;		//pace period4 small leg initial value
	unsigned char p4_sleg_add;		//pace period4 small leg add value
	unsigned char p4_sleg_sub;		//pace period4 small leg subtract value
	// 
};
float a;


struct st_mortor_param_2
{ 
	//
	unsigned int p1_time;					//pace period1 length of time
	unsigned int p1_bleg_init;		//pace period1 big leg initial value
	unsigned char p1_bleg_add1;		//pace period1 big leg add value
	unsigned char p1_bleg_add2;		//pace period1 big leg add value
	unsigned char p1_bleg_sub1;		//pace period1 big leg subtract value
	unsigned char p1_bleg_sub2;		//pace period1 big leg subtract value
	unsigned int p1_sleg_init;		//pace period1 small leg initial value
	unsigned char p1_sleg_add1;		//pace period1 big leg add value
	unsigned char p1_sleg_add2;		//pace period1 big leg add value
	unsigned char p1_sleg_sub1;		//pace period1 big leg subtract value
	unsigned char p1_sleg_sub2;		//pace period1 big leg subtract value
	//
	unsigned int p2_time;					//pace period1 length of time
	unsigned int p2_bleg_init;		//pace period1 big leg initial value
	unsigned char p2_bleg_add1;		//pace period1 big leg add value
	unsigned char p2_bleg_add2;		//pace period1 big leg add value
	unsigned char p2_bleg_sub1;		//pace period1 big leg subtract value
	unsigned char p2_bleg_sub2;		//pace period1 big leg subtract value
	unsigned int p2_sleg_init;		//pace period1 small leg initial value
	unsigned char p2_sleg_add1;		//pace period1 big leg add value
	unsigned char p2_sleg_add2;		//pace period1 big leg add value
	unsigned char p2_sleg_sub1;		//pace period1 big leg subtract value
	unsigned char p2_sleg_sub2;		//pace period1 big leg subtract value
	//  
	unsigned int p3_time;					//pace period1 length of time
	unsigned int p3_bleg_init;		//pace period1 big leg initial value
	unsigned char p3_bleg_add1;		//pace period1 big leg add value
	unsigned char p3_bleg_add2;		//pace period1 big leg add value
	unsigned char p3_bleg_sub1;		//pace period1 big leg subtract value
	unsigned char p3_bleg_sub2;		//pace period1 big leg subtract value
	unsigned int p3_sleg_init;		//pace period1 small leg initial value
	unsigned char p3_sleg_add1;		//pace period1 big leg add value
	unsigned char p3_sleg_add2;		//pace period1 big leg add value
	unsigned char p3_sleg_sub1;		//pace period1 big leg subtract value
	unsigned char p3_sleg_sub2;		//pace period1 big leg subtract value
	//

};

//struct st_mortor_param leg1_param = {150,1900,2,0,1400,4,0              ,150,2200,0,2,2000,0,4        ,150,1900,0,0,1400,0,0            ,150,1900,0,0,1400,0,0};
struct st_mortor_param leg1_param_1 = {100,400,2,0,-100,4,0              ,100,600,0,2,300,0,4        ,100,400,0,0,-100,0,0            ,100,400,0,0,-100,0,0};
struct st_mortor_param leg2_param = {75,1500,2,0,1500,4,0              ,75,1650,0,2,1800,0,4        ,75,1500,0,0,1500,0,0            ,75,1500,0,0,1500,0,0};
struct st_mortor_param leg3_param_1 = {100,800,1,0,-0,3,0              ,100,900,0,1,300,0,3        ,100,800,0,0,-0,0,0            ,100,800,0,0,-0,0,0};
//new change step
struct st_mortor_param leg1_param_2 = {100,400,2,0,-100,4,0              ,200,600,0,1,300,0,2        ,300,400,0,0,-100,0,0            ,0,400,0,0,-100,0,0};//qian tui
struct st_mortor_param leg3_param_2 = {100,800,2,0,-0,4,0              ,200,1000,0,1,400,0,2        ,300,800,0,0,-0,0,0            ,0,800,0,0,-0,0,0};//hou tui
//go ahead
struct st_mortor_param leg1_param_3 = {100,400,2,0,-100,3,0              ,100,600,0,1,200,1,0        ,100,500,0,4,300,0,7            ,300,100,1,0,-400,1,0};//qian tui
struct st_mortor_param leg3_param_3 = {100,800,2,0,-0,4,0              ,200,900,0,1,200,0,2        ,300,700,0,0,400,0,0            ,0,600,0,0,200,0,0};//hou tui
//AA1150021150311004160050900613707230081500

	
struct st_mortor_param leg1_param,leg2_param,leg3_param,leg4_param;
//////////////////////////////////////

 int main(void)
 {	 
  
 
	delay_init();	    	 //��ʱ������ʼ��	  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�   
	uart3_init(9600);
	 uart4_init(9600);
	LED_Init();		  		//��ʼ����LED���ӵ�Ӳ���ӿ�
 	BEEP_Init();			//��������ʼ��	
	KEY_Init();				//������ʼ��
	 TIM_PWM_Init();
	 

	OSInit();  	 			//��ʼ��UCOSII		 			  
 	OSTaskCreate(start_task,(void *)0,(OS_STK *)&START_TASK_STK[START_STK_SIZE-1],START_TASK_PRIO );//������ʼ����
	OSStart();	    
}



u16 num_1ms,num13,num24;

//��ʼ����
void start_task(void *pdata)
{
  OS_CPU_SR cpu_sr=0;
	u8 err;
	u8 i;
	pdata = pdata; 		 
	num_1ms = 0;
	num13 = 0;
	num24 = 0;
	state_13 = 0;
	state_24 = 0;
  sem_1ms = OSSemCreate(0);
	sem_leg13 = OSSemCreate(0);
	sem_leg24 = OSSemCreate(0);
//	 pwm_out_1(1500);
//	 pwm_out_2(1500);		
//	 pwm_out_3(1500);		
//	 pwm_out_4(1500);		
//	 pwm_out_5(1500);		
//	 pwm_out_6(1500);		
//	 pwm_out_7(1500);		
//	 pwm_out_8(1500);		
//	 pwm_out_9(1500);		
//	 pwm_out_10(1500);		
//	 pwm_out_11(1500);		
//	 pwm_out_12(1500);
//AA1225022200307504080050800607007220082300
		leg_ori_val[1]=2200;//
		leg_ori_val[2]=2200;//
		
		leg_ori_val[3]=800;//
		leg_ori_val[4]=800;//
		
		leg_ori_val[5]=800;//
		leg_ori_val[6]=700;//
		
		leg_ori_val[7]=2200;//
		leg_ori_val[8]=2300;//
	 for(i = 0;i<=7;i++)
	{
		leg_val[i+1] = leg_ori_val[i+1];
//		leg_val[i+1] = 1500;
	}
	////
	leg1_param = leg1_param_2;
	leg3_param = leg3_param_2;
	///
	OSStatInit();					//��ʼ��ͳ������.�������ʱ1��������	
 	OS_ENTER_CRITICAL();			//�����ٽ���(�޷����жϴ��)    
	//tmr1=OSTmrCreate(1,1,OS_TMR_OPT_PERIODIC,(OS_TMR_CALLBACK)tmr1_callback,0,"tmr1",&err);		//1msִ��һ��
 	OSTaskCreate(led_task,(void *)0,(OS_STK*)&LED_TASK_STK[LED_STK_SIZE-1],LED_TASK_PRIO);						    				   
 	OSTaskCreate(LEG13_task,(void *)0,(OS_STK*)&LEG13_TASK_STK[LEG13_STK_SIZE-1],LEG13_TASK_PRIO);	 				
 	OSTaskCreate(LEG24_task,(void *)0,(OS_STK*)&LEG24_TASK_STK[LEG24_STK_SIZE-1],LEG24_TASK_PRIO);	 	
 	OSTaskCreate(key_task,(void *)0,(OS_STK*)&KEY_TASK_STK[KEY_STK_SIZE-1],KEY_TASK_PRIO);	 	
	//OSTmrStart(tmr1,&err);//����������ʱ��1		
	TIM4_Int_Init(72,1000);
 	OSTaskSuspend(START_TASK_PRIO);	//������ʼ����.
	OS_EXIT_CRITICAL();				//�˳��ٽ���(���Ա��жϴ��)
}	  
//no use 
void tmr1_callback(OS_TMR *ptmr,void *p_arg) 
{
 	static u16 cpuusage=0;
	static u8 tcnt=0;
	static OS_CPU_SR cpu_sr=0;

	OS_ENTER_CRITICAL();
	/**** rectify the value of se0rvo ****/
	
		leg_val_real[1]=leg_val[1]+110;//110
		leg_val_real[2]=leg_val[2]+85;//85

		leg_val_real[3]=leg_val[3]-50;//-35
		leg_val_real[4]=leg_val[4]-65;//-65

		leg_val_real[5]=leg_val[5]+30;//30
		leg_val_real[6]=leg_val[6]-55;//-55

		leg_val_real[7]=leg_val[7]+20;//20
		leg_val_real[8]=leg_val[8]-25;//-80
		//////////////////////////////////


		OSSemPost(sem_1ms);
		OSSemPost(sem_leg13);
		OSSemPost(sem_leg24);
	OS_EXIT_CRITICAL();	
		   
 }

 
//LED����
void led_task(void *pdata)
{   
	u8 err;
	static OS_CPU_SR cpu_sr=0;
	while(1)
	{  
			OSSemPend(sem_1ms,0,&err);
		
		/**/		
		OS_ENTER_CRITICAL();
		pwm_out_1(1500);
		pwm_out_2(1500);		
		pwm_out_3(1500);		
		pwm_out_4(1500);		
		pwm_out_5(1500);		
		pwm_out_6(1500);		
	  pwm_out_7(1500);		
	  pwm_out_8(1500);		
		pwm_out_9(1500);		
		pwm_out_10(1500);		
	  pwm_out_11(1500);		
	  pwm_out_12(1500);
			num_1ms++;
		if(num_1ms >=500)
		{
			//LED1 =! LED1;
			num_1ms = 0;
		}
		OS_EXIT_CRITICAL();	
	}									 
}	   

//����������
void LEG13_task(void *pdata)
{
	u8 err;
	static OS_CPU_SR cpu_sr=0;
	m_cPeriodNum = 0;
	m_nPWMTimer = 0;
	while(1)
	{  	
		 OSSemPend(sem_leg13,0,&err);
		OS_ENTER_CRITICAL();
		num13++;
		if(num13 >=500)
		{
			LED2 =! LED2;
			num13 = 0;
		}

		OS_EXIT_CRITICAL();	
	}									 
}

//����������
void LEG24_task(void *pdata)
{
	u8 err;
	
	while(1)
	{  	
		 OSSemPend(sem_leg24,0,&err);
		num24++;
		if(num24 >=1000)
		{
			LED3 =! LED3;
			num24 = 0;
		}

	}									 
}



//����ɨ������
void key_task(void *pdata)
{	
	u8 key[3],key_state[3];
	
	while(1)
	{
//		key=KEY_Scan(0);
		key[1] = KEY1;
		if(key_state[1] != key[1])
		{
			key_state[1] = key[1];
		if(key_state[1] == 0)
		{

			BEEP=!BEEP;
		}
	  }
		
		key[2] = KEY2;
		if(key_state[2] != key[2])
		{
			key_state[2] = key[2];
		if(key_state[2] == 0)
		{
			
			LED4=!LED4;
			
			
		}
	  }
		
 		delay_ms(10);
	}
}


