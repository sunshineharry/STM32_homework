#include "stm32f10x.h"
#include "pwm.h"
#include "sys.h" 
#include "delay.h"
//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//ALIENTEKս��STM32������
//������������	   
//����ԭ��@ALIENTEK
//������̳:www.openedv.com
//�޸�����:2012/9/3
//�汾��V1.0
//��Ȩ���У�����ؾ���
//Copyright(C) �������������ӿƼ����޹�˾ 2009-2019
//All rights reserved									  
//////////////////////////////////////////////////////////////////////////////////  



void TIM_PWM_Init(void)
{
		
		GPIO_InitTypeDef     GPIO_InitStrue;
    TIM_OCInitTypeDef     TIM_OCInitStrue;
    TIM_TimeBaseInitTypeDef     TIM_TimeBaseInitStrue;
    //
		TIM_DeInit(TIM1);
		TIM_DeInit(TIM8);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8,ENABLE);
	
      
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    
    GPIO_InitStrue.GPIO_Pin= GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;     // TIM3_CH3 --> PB0 TIM3_CH4 --> PB1 
    GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;   
    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_50MHz;    
    GPIO_Init(GPIOC,&GPIO_InitStrue); 
	
		GPIO_InitStrue.GPIO_Pin= GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;     // TIM3_CH3 --> PB0 TIM3_CH4 --> PB1 
//		GPIO_InitStrue.GPIO_Pin= GPIO_Pin_8|GPIO_Pin_9;     // TIM3_CH3 --> PB0 TIM3_CH4 --> PB1 
		GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;   
    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_50MHz;    
    GPIO_Init(GPIOA,&GPIO_InitStrue); 
    //
		TIM_TimeBaseInitStrue.TIM_Period=arr_2;    
    TIM_TimeBaseInitStrue.TIM_Prescaler=psc_2; 
		TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;    
    TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;
		TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStrue); 
		//
		TIM_TimeBaseInitStrue.TIM_Period=arr_3;    
    TIM_TimeBaseInitStrue.TIM_Prescaler=psc_3; 
		TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;    
    TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;
		TIM_TimeBaseInit(TIM5,&TIM_TimeBaseInitStrue); 
		//
		TIM_TimeBaseInitStrue.TIM_Period=arr_4;    
    TIM_TimeBaseInitStrue.TIM_Prescaler=psc_4; 
		TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;    
    TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;
		TIM_TimeBaseInitStrue.TIM_RepetitionCounter = 0;
		TIM_TimeBaseInit(TIM8,&TIM_TimeBaseInitStrue); 
		//
    //
    TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		/*********************/
		//TIM5
    TIM_OC4Init(TIM5,&TIM_OCInitStrue);  
    TIM_OC4PreloadConfig(TIM5,TIM_OCPreload_Enable);         
    //
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
    TIM_OC3Init(TIM5,&TIM_OCInitStrue);  
    TIM_OC3PreloadConfig(TIM5,TIM_OCPreload_Enable);
		
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OC2Init(TIM5,&TIM_OCInitStrue);  
    TIM_OC2PreloadConfig(TIM5,TIM_OCPreload_Enable);
		
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
    TIM_OC1Init(TIM5,&TIM_OCInitStrue);  
    TIM_OC1PreloadConfig(TIM5,TIM_OCPreload_Enable);  
		/********************/
		//TIM8
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OC4Init(TIM8,&TIM_OCInitStrue);  
    TIM_OC4PreloadConfig(TIM8,TIM_OCPreload_Enable);         
    //
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
    TIM_OC3Init(TIM8,&TIM_OCInitStrue);  
    TIM_OC3PreloadConfig(TIM8,TIM_OCPreload_Enable);
		
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OC2Init(TIM8,&TIM_OCInitStrue);  
    TIM_OC2PreloadConfig(TIM8,TIM_OCPreload_Enable);
		
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
    TIM_OC1Init(TIM8,&TIM_OCInitStrue);  
    TIM_OC1PreloadConfig(TIM8,TIM_OCPreload_Enable);

		/********************/
		//TIM3
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OC2Init(TIM3,&TIM_OCInitStrue);  
    TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);         
    //
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
    TIM_OC1Init(TIM3,&TIM_OCInitStrue);  
    TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Enable);
		TIM_ARRPreloadConfig(TIM3, ENABLE);
		TIM_ARRPreloadConfig(TIM5, ENABLE);
		TIM_ARRPreloadConfig(TIM8, ENABLE);
		
		
		TIM_CtrlPWMOutputs(TIM8, ENABLE);                             //pwm8
    TIM_Cmd(TIM3,ENABLE);  
		TIM_Cmd(TIM5,ENABLE); 
		TIM_Cmd(TIM8,ENABLE); 
		
		                      //pwm1
    TIM_TimeBaseInitStrue.TIM_Period=arr_1;    
    TIM_TimeBaseInitStrue.TIM_Prescaler=psc_1;       
    TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;    
    TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;       
    TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStrue);         
		//
		//TIM1
		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
		TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
		TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OCInitStrue.TIM_Pulse = 0;
		TIM_TimeBaseInitStrue.TIM_RepetitionCounter = 0;
		TIM_OC2Init(TIM1,&TIM_OCInitStrue);  
		TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Enable);

		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
		TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
		TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
		TIM_OC1Init(TIM1,&TIM_OCInitStrue);  
		TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable);  

		//
		TIM_ARRPreloadConfig(TIM1, ENABLE);
		TIM_CtrlPWMOutputs(TIM1, ENABLE); 
		TIM_Cmd(TIM1,ENABLE);  
}

//void TIM_PWM_Init(void)
//{
//		GPIO_InitTypeDef     GPIO_InitStrue;
//    TIM_OCInitTypeDef     TIM_OCInitStrue;
//    TIM_TimeBaseInitTypeDef     TIM_TimeBaseInitStrue;
//    //
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  
//		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
//	
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8,ENABLE);
//	
//      
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
//    

//	
//		GPIO_InitStrue.GPIO_Pin= GPIO_Pin_8|GPIO_Pin_9;     // TIM3_CH3 --> PB0 TIM3_CH4 --> PB1 
//		GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;   
//    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_50MHz;    
//    GPIO_Init(GPIOA,&GPIO_InitStrue); 
//    //
//		
//		
//		                      //pwm1
//    TIM_TimeBaseInitStrue.TIM_Period=arr_1;    
//    TIM_TimeBaseInitStrue.TIM_Prescaler=psc_1;       
//    TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;    
//    TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;       
//    TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStrue);         
//		//
//		//TIM1
//		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
//    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
//    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
//		TIM_OC2Init(TIM1,&TIM_OCInitStrue);  
//		
//		TIM_OCInitStrue.TIM_OCMode=TIM_OCMode_PWM2;        
//    TIM_OCInitStrue.TIM_OCPolarity=TIM_OCPolarity_High; 
//    TIM_OCInitStrue.TIM_OutputState=TIM_OutputState_Enable; 
//    TIM_OC1Init(TIM1,&TIM_OCInitStrue);  
//		
//		TIM_CtrlPWMOutputs(TIM1, ENABLE); 
//    TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable);  
//    TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Enable);
//		//
//		TIM_ARRPreloadConfig(TIM1, ENABLE);
//		TIM_Cmd(TIM1,ENABLE);       
//}


void pwm_out_1(u16 set_compare)
{
	TIM_SetCompare1(TIM5,20000-set_compare);
}

void pwm_out_2(u16 set_compare)
{
	TIM_SetCompare2(TIM5,20000-set_compare);
}

void pwm_out_3(u16 set_compare)
{
	TIM_SetCompare3(TIM5,20000-set_compare);
}
/************************/
void pwm_out_4(u16 set_compare)
{
	TIM_SetCompare4(TIM5,20000-set_compare);
}

void pwm_out_5(u16 set_compare)
{
	TIM_SetCompare1(TIM3,20000-set_compare);
}

void pwm_out_6(u16 set_compare)
{
	TIM_SetCompare2(TIM3,20000-set_compare);
}
/*********************/
void pwm_out_7(u16 set_compare)
{
	TIM_SetCompare1(TIM8,20000-set_compare);
}

void pwm_out_8(u16 set_compare)
{
	TIM_SetCompare2(TIM8,20000-set_compare);
}

void pwm_out_9(u16 set_compare)
{
	TIM_SetCompare3(TIM8,20000-set_compare);
}
/************************/
void pwm_out_10(u16 set_compare)
{
	TIM_SetCompare4(TIM8,20000-set_compare);
}

void pwm_out_11(u16 set_compare)
{
	TIM_SetCompare1(TIM1,20000-set_compare);
}

void pwm_out_12(u16 set_compare)
{
	TIM_SetCompare2(TIM1,20000-set_compare);
}
/*********************/