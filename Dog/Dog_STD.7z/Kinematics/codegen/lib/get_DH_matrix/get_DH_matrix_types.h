/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: get_DH_matrix_types.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 12-May-2021 12:50:57
 */

#ifndef GET_DH_MATRIX_TYPES_H
#define GET_DH_MATRIX_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for get_DH_matrix_types.h
 *
 * [EOF]
 */
