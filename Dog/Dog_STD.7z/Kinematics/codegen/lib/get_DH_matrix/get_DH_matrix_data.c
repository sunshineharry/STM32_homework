/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: get_DH_matrix_data.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 12-May-2021 12:50:57
 */

/* Include Files */
#include "get_DH_matrix_data.h"
#include "get_DH_matrix.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
bool isInitialized_get_DH_matrix = false;

/*
 * File trailer for get_DH_matrix_data.c
 *
 * [EOF]
 */
