#include "stm32f10x_conf.h"
#include "pwm.h"
#include "beep.h"
#include "usart.h"



static void Init(void)
{
    UART3_Init(115200);
    LOG_DEBUG("System satrt up!");
    BEEP_Init();
    PWM_Init();
    LOG_DEBUG("System init finished!");
}



int main(void)
{
    Init();
    while (1)
    {
        PWM_Output(YH_LEG1,90);
        PWM_Output(YH_LEG2,90);
        PWM_Output(ZH_LEG1,90);
        PWM_Output(ZH_LEG2,90);
        PWM_Output(YQ_LEG1,90);
        PWM_Output(YQ_LEG2,90);
        PWM_Output(ZQ_LEG1,90);
        PWM_Output(ZQ_LEG2,90);
    }
}
