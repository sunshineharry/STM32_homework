/*-----------------------------------------------------------------------------------*/
/* Auto generate by EIDE, don't modify this file, any changes will be overwritten ! */
/*-----------------------------------------------------------------------------------*/

#ifndef _H_RTE_COMPONENTS
#define _H_RTE_COMPONENTS

#endif
